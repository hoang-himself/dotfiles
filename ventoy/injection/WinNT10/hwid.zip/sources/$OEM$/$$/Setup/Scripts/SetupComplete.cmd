@echo off

reg query HKU\S-1-5-19 1>nul 2>nul || exit /b

start /b /wait cmd /c "%~dp0HWID_Activation_AIO.cmd" /a

cd \
(goto) 2>nul & (if "%~dp0"=="%SystemRoot%\Setup\Scripts\" rd /s /q "%~dp0")